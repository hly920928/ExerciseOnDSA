#pragma once
#include <vector>
int countRangeSum(std::vector<int>& nums, int lower, int upper);